const http = require('http');

const server = http.createServer();
server.listen(80);
