var stringName = "Banana Orange Apple Mangoo";
function myFunction(stringName){
    var stringName = "Banana Orange Apple Mangoo"; 
    var Arr = new Array(stringName); 
    console.log(Arr); 
    for(var i=0;i<Arr.length;i++){
        console.log(Arr[i]);
    }
};
myFunction() 