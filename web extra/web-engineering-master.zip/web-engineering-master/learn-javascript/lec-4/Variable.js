var name = "asad";
var age = 35;
var height = 6.1;
var isMale = true;

var fatherName; //declaration
fatherName = "M.Rafiq Khan";//initialization

var fatherName = "M. Rafiq Khan"; //declaration + initialization

var profession = "software engineer";//declaration + initialzation


console.log(profession1);






