function log(content) {
    var textDiv = document.getElementById("text-container");
    textDiv.textContent = content;
}

var num1 = 12;
var num2 = 3;

num1--;
log(num1);

