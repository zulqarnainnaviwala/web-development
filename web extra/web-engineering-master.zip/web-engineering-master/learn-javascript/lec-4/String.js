function log(content) {
    var textDiv = document.getElementById("text-container");
    textDiv.textContent = content;
}
/*
var name = "Asad";
var firstCharacter = name[name.length + 1];
log(firstCharacter);
*/

/*
var sampleText = 'I am "asad" and I am studing' ;
log(sampleText);
var sampleText = "I am \"asad\" and I am studing" ;
log(sampleText);
*/

// var name = "Asad";
// var myClass = "1st";
// var printResult = "I am " + name + " and I'm studing in " + myClass + " class";
// log(printResult);

/*
var num1 = 1;
var num2 = 3;
var name = "Asad";
var result = num1 + name + num2;
log(result);
*/


