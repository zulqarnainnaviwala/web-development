function testVariables() {
    var num = 5;
    if(num == 5){
        let  num2 = 6;
        console.log(num2);
    }   
    console.log(num2);
}


testVariables();