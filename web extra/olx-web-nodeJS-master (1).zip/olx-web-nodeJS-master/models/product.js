var mongoose = require('mongooose');
var Schema = mongoose.Schema;

var schema = new Schema({

});

model.exports = mongoose.model('Product',schema);