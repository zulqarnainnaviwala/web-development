# olx-web-nodeJS

OLX Ecommerce Web using Node-JS



## Install
    $ npm install

## Start & watch

    $ npm start

## Simple build for production

    $ npm run build

## Inside Web

![46810989_513277645835922_7518171790145748992_n](https://user-images.githubusercontent.com/42208796/52901677-653ba880-3228-11e9-91c4-9954bfef3e4b.png)
![46818521_270722216962311_9196623435801821184_n](https://user-images.githubusercontent.com/42208796/52901678-65d43f00-3228-11e9-9f50-081c65dfee49.png)
![46893827_1798966043563954_9171591851004657664_n](https://user-images.githubusercontent.com/42208796/52901679-65d43f00-3228-11e9-93d4-1aabaf9baa60.png)
![46961827_288337691791742_4138424568513560576_n](https://user-images.githubusercontent.com/42208796/52901680-65d43f00-3228-11e9-9475-4de86885735d.png)
![46981254_205647440376032_5279565841115906048_n](https://user-images.githubusercontent.com/42208796/52901681-666cd580-3228-11e9-980e-c816c7ad0c78.png)
![46982070_307491969859214_2040092869846368256_n](https://user-images.githubusercontent.com/42208796/52901682-666cd580-3228-11e9-8ce3-1fefc8dcd3a3.png)

